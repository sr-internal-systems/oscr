# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['oscr']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.22,<3.0', 'simple-salesforce>=0.74.3,<0.75.0']

setup_kwargs = {
    'name': 'oscr',
    'version': '0.1.0',
    'description': 'The Opinionated System for Contact Retrieval.',
    'long_description': None,
    'author': 'Elliott Maguire',
    'author_email': 'e.maguire@smartrecruiters.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
