"""
oscr.main
~~~~~~~~~

This module implements the the system's main script.
"""

from oscr.utils import run


def main():
    run()


if __name__ == "__main__":
    main()
